<?php

namespace Tangibledesign\Framework\Actions\Subscriptions;

class UpdateSubscriptionAction
{

    public function execute(array $data): void
    {

    }

}