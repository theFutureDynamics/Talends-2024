<?php


namespace Tangibledesign\Framework\Models;


use Tangibledesign\Framework\Models\Term\Term;

/**
 * Class Category
 * @package Tangibledesign\Framework\Models
 */
class Category extends Term
{

}