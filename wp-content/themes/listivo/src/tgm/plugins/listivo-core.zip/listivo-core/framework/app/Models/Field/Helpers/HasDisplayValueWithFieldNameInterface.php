<?php

namespace Tangibledesign\Framework\Models\Field\Helpers;

interface HasDisplayValueWithFieldNameInterface
{
    /**
     * @return bool
     */
    public function displayValueWithFieldName(): bool;
}