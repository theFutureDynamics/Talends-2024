<?php


namespace Tangibledesign\Framework\Models\Field\Helpers;


trait HasTextBeforeValue
{

}