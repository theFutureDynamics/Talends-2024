<?php

namespace Tangibledesign\Framework\Models\Helpers;

trait HasId
{
    abstract public function getId(): int;
}