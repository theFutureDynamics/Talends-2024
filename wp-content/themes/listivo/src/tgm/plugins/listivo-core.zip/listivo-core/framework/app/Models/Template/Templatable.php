<?php


namespace Tangibledesign\Framework\Models\Template;


/**
 * Interface Templatable
 * @package Tangibledesign\Framework\Models\Template
 */
interface Templatable
{

}