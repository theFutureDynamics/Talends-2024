<?php

namespace Tangibledesign\Framework\Models\User;

class BusinessUser extends User
{

}