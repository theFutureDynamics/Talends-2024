<?php


namespace Tangibledesign\Framework\Models\User\Helpers;


/**
 * Interface HasSocialProfilesInterface
 * @package Tangibledesign\Framework\Models\User\Helpers
 */
interface HasSocialProfilesInterface
{


}