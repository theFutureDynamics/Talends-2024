<?php

namespace Tangibledesign\Framework\Models\User;

class PrivateUser extends User
{

}